# Партия 2: 21 проба (редакция с именем Егор)

- skin/probes.json — тексты (правятся)
- structure/probes.json — векторы, роли, порядок, id (не править)
- built/ — собранное для игры

После правки: npm run v25:build, затем npm run check.
