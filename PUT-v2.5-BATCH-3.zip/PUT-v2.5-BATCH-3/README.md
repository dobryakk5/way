# Партия 3: 50 карточек шести дуг + стадийные варианты ironic

- skin/development.json — тексты карточек дуг (правятся); skin/arcs.json — тексты дуг (способность, вопрос, итог); skin/ironic-stage-variants.json — три варианта текста для стадии ironic (живут в cards.continuation.json)
- structure/development.json — id, события, роли (не править)
- built/ — собранное для игры

После правки: npm run v25:build, затем npm run check. Флаг rollout.developmentArcs пока выключен.
