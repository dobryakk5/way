# Партия 1: 32 neutral + 8 вопросов о мотиве + 4 продолжения (редакция с именем Егор)

- skin/ — тексты (правятся): neutral.json (вопросы о мотиве внутри сцен, поле motive), behaviors.json
- structure/ — векторы логик, порядок вариантов, id, роли (не править)
- built/ — собранное для игры; characters.json — люди села

После правки: npm run v25:build, затем npm run check.
